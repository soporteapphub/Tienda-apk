import glob
import os
import re
import shutil

# ---------------- AndroidManifest ----------------
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()

perms = '''    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
    <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
    <uses-feature android:name="android.software.leanback" android:required="false"/>
'''
i = s.index('>', s.index('<manifest')) + 1
s = s[:i] + '\n' + perms + s[i:]

s = re.sub(r'android:label="[^"]*"', 'android:label="Tienda APK"', s, count=1)
launcher = '<category android:name="android.intent.category.LAUNCHER"/>'
s = s.replace(launcher, launcher + '\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>', 1)

prov = '''        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/tienda_paths"/>
        </provider>
'''
s = s.replace('</application>', prov + '    </application>', 1)
open(p, 'w', encoding='utf-8').write(s)

os.makedirs('android/app/src/main/res/xml', exist_ok=True)
open('android/app/src/main/res/xml/tienda_paths.xml', 'w', encoding='utf-8').write(
    '<?xml version="1.0" encoding="utf-8"?>\n<paths>\n'
    '    <cache-path name="apks" path="."/>\n</paths>\n')
print('AndroidManifest.xml listo')

# ---------------- MainActivity nativa ----------------
pkg_dir = 'android/app/src/main/kotlin/com/tienda/tienda_apk'
os.makedirs(pkg_dir, exist_ok=True)
for f in glob.glob('android/app/src/main/kotlin/**/MainActivity.*', recursive=True):
    os.remove(f)
for f in glob.glob('android/app/src/main/java/**/MainActivity.*', recursive=True):
    os.remove(f)
shutil.copy('tools/MainActivity.kt', pkg_dir + '/MainActivity.kt')
print('MainActivity lista')

# ---------------- Firma fija (para poder actualizar la propia tienda) ----------------
kts = os.path.exists('android/app/build.gradle.kts')
path = 'android/app/build.gradle.kts' if kts else 'android/app/build.gradle'
g = open(path, encoding='utf-8').read()
shutil.copy('tools/tienda.jks', 'android/app/tienda.jks')
if kts:
    block = '''    signingConfigs {
        create("tienda") {
            storeFile = file("tienda.jks")
            storePassword = "tienda2026"
            keyAlias = "tienda"
            keyPassword = "tienda2026"
        }
    }

'''
    g2 = g.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("tienda")')
else:
    block = '''    signingConfigs {
        tienda {
            storeFile file('tienda.jks')
            storePassword 'tienda2026'
            keyAlias 'tienda'
            keyPassword 'tienda2026'
        }
    }

'''
    g2 = g.replace('signingConfigs.debug', 'signingConfigs.tienda')
m = re.search(r'^([ \t]*)buildTypes\s*\{', g2, re.M)
if not m or g2 == g:
    raise SystemExit('ERROR: no se pudo configurar la firma en ' + path)
g2 = g2[:m.start()] + block + g2[m.start():]
open(path, 'w', encoding='utf-8').write(g2)
print('Firma fija configurada en', path)
