TIENDA APK - descarga e instala las APK de un repositorio de GitHub

COMPILAR (GitHub Actions)
1. Crea un repositorio y sube TODO el contenido de esta carpeta (incluida .github).
2. Settings > Actions > General > Workflow permissions > Read and write.
3. Actions > Build APK > Run workflow. El APK queda en Releases.

USO
1. Abre la app y escribe el repositorio: usuario/repositorio.
   Debe tener APK adjuntas en sus Releases.
2. Marca las APK (o "Seleccionar todas") y pulsa "Descargar e instalar".
3. Android pide confirmar cada instalación; al volver a la tienda sigue
   con la siguiente. La primera vez hay que permitir "instalar apps
   desconocidas" para Tienda APK.
- Repositorio privado: agrega un token (solo lectura de contenido) en el engrane.
