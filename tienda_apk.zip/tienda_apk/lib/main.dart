import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _ch = MethodChannel('tienda/install');
const _ua = 'tienda-apk';

void main() => runApp(const TiendaApp());

class TiendaApp extends StatelessWidget {
  const TiendaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Tienda APK',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorSchemeSeed: const Color(0xFFF5A02A),
        ),
        home: const Home(),
      );
}

class Apk {
  Apk(this.name, this.size, this.tag, this.date, this.apiUrl, this.webUrl);
  final String name, tag, date, apiUrl, webUrl;
  final int size;
  bool selected = false;
  String status = '';
  double? progress;
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  SharedPreferences? _p;
  String repo = '', token = '';
  bool onlyLatest = true;
  List<Apk> items = [];
  bool loading = false, running = false, cancel = false;
  String? error;

  Completer<void>? _waiter;
  bool _wasPaused = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused || s == AppLifecycleState.inactive) {
      _wasPaused = true;
    } else if (s == AppLifecycleState.resumed && _wasPaused) {
      _wasPaused = false;
      final w = _waiter;
      if (w != null && !w.isCompleted) w.complete();
    }
  }

  Future<void> _init() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    repo = p.getString('repo') ?? '';
    token = p.getString('token') ?? '';
    onlyLatest = p.getBool('onlyLatest') ?? true;
    if (!mounted) return;
    setState(() {});
    if (repo.isEmpty) {
      await _settings();
    } else {
      await _load();
    }
  }

  Map<String, String> _headers() => {
        'Accept': 'application/vnd.github+json',
        'User-Agent': _ua,
        if (token.isNotEmpty) 'Authorization': 'Bearer $token',
      };

  String _fmt(String? iso) {
    final d = DateTime.tryParse(iso ?? '')?.toLocal();
    if (d == null) return '';
    String t(int n) => n.toString().padLeft(2, '0');
    return '${t(d.day)}/${t(d.month)}/${d.year} ${t(d.hour)}:${t(d.minute)}';
  }

  String _mb(int b) => b <= 0 ? '' : '${(b / 1048576).toStringAsFixed(1)} MB';

  void _snack(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _settings() async {
    final rc = TextEditingController(text: repo);
    final tc = TextEditingController(text: token);
    var latest = onlyLatest;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Repositorio'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: rc,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'usuario/repositorio',
                  hintText: 'ejemplo: miusuario/misapps',
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: tc,
                autocorrect: false,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Token (solo si el repositorio es privado)',
                ),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Solo la versión más reciente de cada APK'),
                value: latest,
                onChanged: (v) => set(() => latest = v),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar')),
          ],
        ),
      ),
    );
    if (ok == true) {
      var r = rc.text.trim();
      r = r.replaceAll(RegExp(r'^https?://github\.com/'), '').replaceAll(RegExp(r'(\.git)?/?$'), '');
      repo = r;
      token = tc.text.trim();
      onlyLatest = latest;
      await _p?.setString('repo', repo);
      await _p?.setString('token', token);
      await _p?.setBool('onlyLatest', onlyLatest);
      if (mounted) setState(() {});
      if (repo.isNotEmpty) await _load();
    }
    rc.dispose();
    tc.dispose();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
      items = [];
    });
    try {
      final r = await http
          .get(Uri.parse('https://api.github.com/repos/$repo/releases?per_page=100'),
              headers: _headers())
          .timeout(const Duration(seconds: 20));
      if (r.statusCode == 404) {
        throw 'No se encontró "$repo". Si es privado, agrega un token en Repositorio.';
      }
      if (r.statusCode != 200) throw 'GitHub respondió ${r.statusCode}';
      final list = jsonDecode(r.body) as List;
      final out = <Apk>[];
      final seen = <String>{};
      for (final rel in list) {
        if (rel['draft'] == true) continue;
        final tag = (rel['tag_name'] ?? '') as String;
        final date = _fmt(rel['published_at'] as String?);
        for (final a in (rel['assets'] as List? ?? const [])) {
          final name = (a['name'] ?? '') as String;
          if (!name.toLowerCase().endsWith('.apk')) continue;
          if (onlyLatest && !seen.add(name)) continue;
          out.add(Apk(name, (a['size'] ?? 0) as int, tag, date,
              (a['url'] ?? '') as String, (a['browser_download_url'] ?? '') as String));
        }
      }
      if (!mounted) return;
      setState(() => items = out);
      if (out.isEmpty) setState(() => error = 'Este repositorio no tiene APK en sus Releases.');
    } catch (e) {
      if (mounted) setState(() => error = '$e'.replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<String> _download(Apk a) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${a.name.replaceAll(RegExp(r'[^\w.\-]'), '_')}');
    if (await file.exists()) await file.delete();
    final client = http.Client();
    try {
      final priv = token.isNotEmpty;
      final req = http.Request('GET', Uri.parse(priv ? a.apiUrl : a.webUrl))
        ..followRedirects = !priv
        ..headers['User-Agent'] = _ua;
      if (priv) {
        req.headers['Accept'] = 'application/octet-stream';
        req.headers['Authorization'] = 'Bearer $token';
      }
      var resp = await client.send(req).timeout(const Duration(seconds: 30));
      if (resp.isRedirect && resp.headers['location'] != null) {
        await resp.stream.drain<void>();
        final r2 = http.Request('GET', Uri.parse(resp.headers['location']!))
          ..headers['User-Agent'] = _ua;
        resp = await client.send(r2).timeout(const Duration(seconds: 30));
      }
      if (resp.statusCode != 200) throw 'HTTP ${resp.statusCode}';
      final total = resp.contentLength ?? a.size;
      var got = 0;
      final sink = file.openWrite();
      try {
        await for (final c in resp.stream) {
          if (cancel) break;
          sink.add(c);
          got += c.length;
          if (total > 0 && mounted) {
            setState(() {
              a.progress = got / total;
              a.status = 'Descargando ${(got * 100 / total).toStringAsFixed(0)} %';
            });
          }
        }
      } finally {
        await sink.close();
      }
      return file.path;
    } finally {
      client.close();
    }
  }

  Future<void> _run() async {
    final todo = items.where((e) => e.selected).toList();
    if (todo.isEmpty) return;
    try {
      final ok = await _ch.invokeMethod<bool>('canInstall') ?? true;
      if (!ok) {
        await _ch.invokeMethod('openSettings');
        _snack('Activa "Permitir desde esta fuente", vuelve y pulsa Instalar otra vez');
        return;
      }
    } catch (_) {}

    setState(() {
      running = true;
      cancel = false;
      for (final a in todo) {
        a.status = 'En cola';
        a.progress = null;
      }
    });

    for (final a in todo) {
      if (cancel) break;
      String? path;
      try {
        path = await _download(a);
        if (cancel) break;
        if (mounted) {
          setState(() {
            a.progress = null;
            a.status = 'Confirma la instalación en pantalla…';
          });
        }
        _wasPaused = false;
        _waiter = Completer<void>();
        await _ch.invokeMethod('install', {'path': path});
        await _waiter!.future; // continúa cuando el usuario vuelve a la tienda
        if (mounted) {
          setState(() {
            a.status = 'Enviada a instalar';
            a.selected = false;
          });
        }
      } catch (e) {
        if (mounted) setState(() => a.status = 'Error: $e');
      } finally {
        if (path != null) {
          try {
            await File(path).delete();
          } catch (_) {}
        }
      }
    }
    if (!mounted) return;
    setState(() {
      running = false;
      for (final a in todo) {
        if (a.status == 'En cola') a.status = '';
      }
    });
  }

  void _stop() {
    cancel = true;
    final w = _waiter;
    if (w != null && !w.isCompleted) w.complete();
  }

  @override
  Widget build(BuildContext context) {
    final sel = items.where((e) => e.selected).length;
    final allSel = items.isNotEmpty && sel == items.length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tienda APK'),
        actions: [
          IconButton(
            tooltip: 'Buscar de nuevo',
            icon: const Icon(Icons.refresh),
            onPressed: (loading || running) ? null : (repo.isEmpty ? _settings : _load),
          ),
          IconButton(
            tooltip: 'Repositorio',
            icon: const Icon(Icons.settings),
            onPressed: running ? null : _settings,
          ),
        ],
      ),
      body: Column(children: [
        if (repo.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(children: [
              const Icon(Icons.folder_open, size: 18),
              const SizedBox(width: 8),
              Expanded(child: Text(repo, style: const TextStyle(fontWeight: FontWeight.w600))),
              if (items.isNotEmpty)
                TextButton(
                  onPressed: running
                      ? null
                      : () => setState(() {
                            for (final a in items) {
                              a.selected = !allSel;
                            }
                          }),
                  child: Text(allSel ? 'Quitar todas' : 'Seleccionar todas'),
                ),
            ]),
          ),
        if (loading) const LinearProgressIndicator(),
        Expanded(
          child: error != null && items.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(error!, textAlign: TextAlign.center),
                  ),
                )
              : ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (c, i) {
                    final a = items[i];
                    return CheckboxListTile(
                      value: a.selected,
                      onChanged: running ? null : (v) => setState(() => a.selected = v ?? false),
                      title: Text(a.name, maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text([a.tag, a.date, _mb(a.size)].where((e) => e.isNotEmpty).join(' · '),
                            style: const TextStyle(fontSize: 12)),
                        if (a.status.isNotEmpty)
                          Text(a.status,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: a.status.startsWith('Error')
                                      ? Colors.redAccent
                                      : Theme.of(context).colorScheme.primary)),
                        if (a.progress != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: LinearProgressIndicator(value: a.progress),
                          ),
                      ]),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: running
                  ? FilledButton.tonalIcon(
                      onPressed: _stop,
                      icon: const Icon(Icons.stop),
                      label: const Text('Detener'),
                    )
                  : FilledButton.icon(
                      onPressed: sel == 0 ? null : _run,
                      icon: const Icon(Icons.download),
                      label: Text(sel == 0 ? 'Elige las APK a instalar' : 'Descargar e instalar ($sel)'),
                    ),
            ),
          ),
        ),
      ]),
    );
  }
}
